#-------------------------------------------------------------------------------
# Name:       matrix-library
# Purpose:    matrix manipulations
#
# Author:      soumya
#
# Created:     04/08/2017
#----------------------------------------
from numpy import *

#For kronecker product using numpy.kron
#multiplies each element of first matrix with elements of second matrix

#clean up
def kronpow(A,n):
	n=n-1 
	if n==-1:
		return 0 #should return eye
	if n==0:
		return A	
	B=kron(A,A) #could have used eye
	for i in range(n-1):
		B=kron(B,A)
	return B

