import numpy as np
import math as ma
import problib as pl
import polarencdec as ec
import polarconstruct as pcon
from datetime import datetime
import json

N=32
K=16

design_p=0.1
I=pcon.getGChZCK(design_p,N,K)[0]
#print I
G=len(I) #number of good channels
D=np.zeros(N-G,dtype=int).tolist()#frozen data

YN=np.random.randint(2,size=N)
YN=np.array([1, 0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 0])

print "YN:"
print YN.tolist()


d=ec.polarSCdecodeG(YN,N,design_p,I,list(D))
print d
print ec.getUN(d,I).tolist()
print "V_5"

"""
[0 1 1 1 1 1 1 1]
[0 0 0 0 0 0 0 1]
[0 0 0 1]
"""
