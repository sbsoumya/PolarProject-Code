#-------------------------------------------------------------------------------
# Name:       polarchannel.py
# Purpose:    polarcodes for channelcoding 
#            
#
# Author:      soumya
#
# Created:     19/08/2017
#----------------------------------------
import numpy as np
import math as ma
import problib as pl
import polarencdec as ec
import polarconstruct as pcon
from datetime import datetime
import json
import matlib as ml
#p is channel_p
def polarchannelsim(N,channel_p,design_p,I,runsim,BER_needed):
	p=channel_p
	G=len(I) #number of good channels
	FD=np.zeros(N-G,dtype=int).tolist()#frozen data
	
	if BER_needed:
		errcnt=np.zeros(G)
	
	block_errorcnt=0
	#print float(len(I))/N
	#UN=np.random.randint(2,size=G)
	#print UN
	for i in range(runsim):
		#print i
		UN=np.random.randint(2,size=G)
		
		XN=ec.polarencodeG(UN,N,I,list(FD),False)
		
		YN=pl.BSCN(p,XN)
		UN_hat=ec.polarSCdecodeG(YN,N,design_p,I,list(FD),False)
		UN_decoded=ec.getUN(UN_hat,I,False)
		if BER_needed:
			errcnt=errcnt+np.logical_xor(UN,UN_decoded)
						
		if UN.tolist()!=UN_decoded.tolist():
			block_errorcnt+=1
		#print UN,YN,UN_decoded
	if BER_needed:		
		berN=errcnt/runsim
		ber_exp=np.log10(berN).tolist()
	
	block_error=float(block_errorcnt)/runsim
		
	if BER_needed:
		return (ber_exp,block_error)
	else:
		return block_error

#============0.04 debug 20-12-2017
#===================================
#===================================
def getreliability_order(N):
	return pcon.getGChZCK(0.01,N,N)[0]
	
def getRatelist(plist,derate):
	#insert derating
	Ratelist=[ pl.CapacityBSC(1,p)*derate for p in plist]
	return Ratelist
	
def adjustG(Glist): #input Glist is sorted
	MaxG=max(Glist)
	lenG=len(Glist)
	lcm=ml.get_lcm_for(range(1,lenG+1))
	return [int(MaxG/lcm)*(lcm/(i+1)) for i in range(lenG)]
	
	return 0
	#for i in range(Glist):
		

#===================================================init inside runsim
def polarchannel2(UN,N,channel_p,compound_plist_u,derate,use_adjusted_Rate):
	p=channel_p
	
	I_ord=getreliability_order(N)
	compound_plist=list(compound_plist_u) #best channel first
	compound_plist.sort()
	design_p=compound_plist[0]
	
	
	Ratelist = getRatelist(compound_plist,derate)       #best rate first
	
	
	
	Glist=[int(N*r) for r in Ratelist]
	
	Glist=adjustG(Glist)

	R=getRatelist([channel_p],derate)[0]  #calculates rate for given channel
	G=int(R*N)
	I=I_ord[:G]
	#G=len(I) #number of good channels
	FD=np.zeros(N-G,dtype=int).tolist()#frozen data
	
	#UN=np.random.randint(2,size=G)
		
	XN=ec.polarencodeG(UN,N,I,list(FD),False)
		
	YN=pl.BSCN(p,XN)
	UN_hat=ec.polarSCdecodeG(YN,N,design_p,I,list(FD),False)
	UN_decoded=ec.getUN(UN_hat,I,False)
	return(np.array(UN_decoded))
    
def polarchannelsim2(N,compound_plist_u,channel_p,derate,runsim,BER_needed):
	p=channel_p
	
	#G=len(I) #number of good channels
	
	compound_plist=list(compound_plist_u) #best channel first
	compound_plist.sort()
	
	Ratelist = getRatelist(compound_plist_u,derate)       #best rate first
	Glist=[int(N*r) for r in Ratelist]
	Glist=adjustG(Glist)
	
	
	if BER_needed:
		errcnt=np.zeros(G)
	
	block_errorcnt=0
	#print float(len(I))/N
	#UN=np.random.randint(2,size=G)
	#print UN
	for i in range(runsim):
		#print i
		UN=np.random.randint(2,size=Glist[0])
		UN_decoded=polarchannel2(UN,N,channel_p,compound_plist_u,derate,True)
		if BER_needed:
			errcnt=errcnt+np.logical_xor(UN,UN_decoded)
						
		if UN.tolist()!=UN_decoded.tolist():
			block_errorcnt+=1
		#print UN,YN,UN_decoded
	if BER_needed:		
		berN=errcnt/runsim
		ber_exp=np.log10(berN).tolist()
	
	block_error=float(block_errorcnt)/runsim
		
	if BER_needed:
		return (ber_exp,block_error)
	else:
		return (float(Glist[0])/N,block_error)
