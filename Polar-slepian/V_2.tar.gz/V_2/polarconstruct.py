#-------------------------------------------------------------------------------
# Name:       monte-carlo for charaterising channel/ code construction
# Purpose:    related to prob and channel
#
# Author:      soumya
#
# Created:     04/08/2017
#----------------------------------------
import numpy as np
import math as ma
import problib as pl
import polarencdec as ec


#simulation params
runsim=1000

"""
#BSC param
p=0.2
N=8

"""
#=================================================Code construction
#NOTE:Zconstruct is good for BEC
def Zconstruct(Z,n):
	ZN1=[]
	ZN2=[]
	ZN1.append(Z)
	for i in range(n):
		for z in ZN1:
			ZN2.append(2*z-z**2)
			ZN2.append(z**2)
		
		ZN1=list(ZN2)
		#print ZN1
		ZN2=[]
		
	return ZN1

#ZN=Zconstruct(pl.ZBSC(0.3),2)
#print ZN,len(ZN) 

def getGChZCK(p,N,K):
	print "ZC(K)..."
	n=int(ma.log(N,2))
	Z=pl.ZBSC(p)	
	ZN=Zconstruct(pl.ZBSC(p),n)
	aZN=np.array(ZN)
	sZN=np.sort(aZN)
	good_channels=aZN.argsort().tolist()[:K]
	exp_error=np.log10(sZN)
	return (good_channels,exp_error[:K])
		
def getGChZCL(p,N,L):#L is error exponent
	print "ZC(error)..."
	n=int(ma.log(N,2))
	Z=pl.ZBSC(p)	
	ZN=Zconstruct(pl.ZBSC(p),n)
	aZN=np.array(ZN)
	sZN=np.sort(aZN)
	exp_error=np.log10(sZN).tolist()
	#print exp_error
	K=0
	for i in exp_error:
		if i<=L:
			K+=1
	
	good_channels=aZN.argsort().tolist()[:K]
	return (good_channels,exp_error[:K])


#---------------------------------Monte Carlo

def getGChMCK(p,N,K):
	err=np.zeros(N)
	print "MC(K)..."+str(runsim)
	for i in range(runsim):
		UN=np.random.randint(2,size=N)
		UN_decoded=ec.polarSCdecode(pl.BSCN(p,ec.polarencode(UN,len(UN))),len(UN),p)
		err=err+np.logical_xor(UN,UN_decoded)
	
	aZN=err/runsim
	sZN=np.sort(aZN)
	good_channels=aZN.argsort().tolist()[:K]
	exp_error=np.log10(sZN)
	return (good_channels,exp_error[:K])
	
def getGChMCL(p,N,L):
	err=np.zeros(N)
	print "MC(error)..."+str(runsim)
	for i in range(runsim):
		UN=np.random.randint(2,size=N)
		UN_decoded=ec.polarSCdecode(pl.BSCN(p,ec.polarencode(UN,len(UN))),len(UN),p)
		err=err+np.logical_xor(UN,UN_decoded)
	
	aZN=err/runsim
	sZN=np.sort(aZN)
	exp_error=np.log10(sZN).tolist()
	#print exp_error
	K=0
	for i in exp_error:
		if i<=L:
			K+=1
	
	good_channels=aZN.argsort().tolist()[:K]
	#print exp_error
	return (good_channels,exp_error[:K])
		
#------------Number of good channels = capacity
print "MONTE _CARLO CHANNEL REPORT"
print "---------------------------"
N=128
p=0.1
print "N="+str(N)
print "p="+str(p)
PotGCh=int(ma.floor(pl.CapacityBSC(N,p)))
print "Capacity for "+str(N)+"channels:"+str(PotGCh)

K=4
tolerable_error= -6
print "No of good channels needed :"+str(K)+"(valid if used)"
print "tolerable error exponent:"+str(tolerable_error)
#-----------------------------------------ZC
(I,E)=getGChZCK(p,N,N)
print "Good Channels:"
print I
print "Corresponding Error Exponents:"
print E
print "Number of good channels:"
print len(I)
R=float(len(I))/N
print "R="+str(R)
print "Frozen channels:"
B=list(set(range(N))-set(I))
print len(B)
		
#-------------------------------------MC

(I,E)=getGChMCK(p,N,N)
print "Good Channels:"
print I
print "Corresponding Error Exponents:"
print E
print "Number of good channels:"
print len(I)
R=float(len(I))/N
print "R="+str(R)
print "Frozen channels:"
B=list(set(range(N))-set(I))
print len(B)

