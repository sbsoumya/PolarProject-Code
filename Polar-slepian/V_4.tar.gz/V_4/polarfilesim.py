import numpy as np
import math as ma
import problib as pl
import polarencdec as ec
import polarconstruct as pcon
from datetime import datetime
import json
import polarfile as pf
#=================================================================simulation		
#------------Number of good channels = capacity
Nlist=[128,1024]
dec_plist=[0.1,0.2]
psteps=0.02

tolerable_error= -6 #using ZCL for channel


runsim=5*10**6


for N in Nlist:
	for dec_p in dec_plist:
		p=0
		stamp=datetime.now().strftime("%d-%m-%y_%H-%M-%S")
		f1=open("./simresults/polarfile_"+str(N)+"_"+str(dec_p)+"_"+stamp+".txt",'w')
			
		print "MONTE _CARLO FILE REPORT"
		print "---------------------------"
		print "N="+str(N)
		print "p_decode="+str(dec_p)
		print "tolerable error exponent:"+str(tolerable_error)# channels selected as per this
		
		json.dump( "MONTE _CARLO FILE REPORT",f1) ;f1.write("\n")
		json.dump( "---------------------------",f1) ;f1.write("\n")
		json.dump( "N="+str(N),f1) ;f1.write("\n")
		json.dump( "p_decode="+str(dec_p),f1) ;f1.write("\n")
		json.dump( "tolerable error exponent:"+str(tolerable_error),f1) ;f1.write("\n")
		
		
		
		#-----------------------------------------ZC
		try:
			I=pcon.getGCHsim('ZL',N,dec_p,tolerable_error)
		except:
		   (I,E)=pcon.getGChZCL(dec_p,N,tolerable_error)
		   
		print "Good Channels:"
		print I
		R=float(len(I))/N
		print "R="+str(R)
		print "Frozen channels:"
		B=list(set(range(N))-set(I))
		print len(B)
		
		json.dump( "Good Channels:",f1) ;f1.write("\n")
		json.dump( I,f1) ;f1.write("\n")
		json.dump( "R="+str(R),f1) ;f1.write("\n")
		json.dump( "Frozen channels:",f1) ;f1.write("\n")
		json.dump( len(B),f1) ;f1.write("\n")
		
		
		
		
		
		while  p<dec_p:
			p+=psteps
			json.dump( "p_channel="+str(p),f1) ;f1.write("\n")
			print "p_channel="+str(p)
			errcnt=np.zeros(N)
			block_errorcnt=0
			for i in range(runsim):
				XN=np.random.randint(2,size=N)
				XN_decoded=pf.polarfiled(XN,p,dec_p,I)
				errcnt=errcnt+np.logical_xor(XN,XN_decoded)
				if XN.tolist()!=XN_decoded.tolist():
					block_errorcnt+=1
					
			berN=errcnt/runsim
			exp_error=np.log10(berN).tolist()
			block_error=float(block_errorcnt)/runsim
			
			#print exp_error
			#print block_error
			
			json.dump( "block_error="+str(block_error),f1) ;f1.write("\n")
			json.dump( "BER channelwise:",f1) ;f1.write("\n")
			json.dump( exp_error,f1) ;f1.write("\n")
		    





