#-------------------------------------------------------------------------------
# Name:       monte-carlo for charaterising channel/ code construction
# Purpose:    related to prob and channel
#
# Author:      soumya
#
# Created:     04/08/2017
#----------------------------------------
import numpy as np
import math as ma
import problib as pl
import polarencdec as ec
from datetime import datetime
import json


#=================================================Code construction
#NOTE:Zconstruct is good for BEC,but gives similar results for BSC
def Zconstruct(Z,n):
	ZN1=[]
	ZN2=[]
	ZN1.append(Z)
	for i in range(n):
		for z in ZN1:
			ZN2.append(2*z-z**2)
			ZN2.append(z**2)
		
		ZN1=list(ZN2)
		#print ZN1
		ZN2=[]
		
	return ZN1

#ZN=Zconstruct(pl.ZBSC(0.3),2)
#print ZN,len(ZN) 

#note the channels from Zconstruct are taken as bit reversed order
def getGChZCK(p,N,K):
	print "ZC(K)..."
	n=int(ma.log(N,2))
	Z=pl.ZBSC(p)	
	ZN=Zconstruct(pl.ZBSC(p),n)
	aZN=np.array(ZN)
	sZN=np.sort(aZN)
	good_channels=aZN.argsort().tolist()[:K]
	exp_error=np.log10(sZN).tolist()
	rgood_channels=ec.bitreverseorder(good_channels,n)
	
	f2=open("./simresults/GCZK_"+str(N)+"_"+str(p).replace(".","p")+"_"+str(K)+".txt",'w')
	json.dump(rgood_channels,f2)
	
	
	return (rgood_channels,exp_error[:K])

		
def getGChZCL(p,N,L):#L is error exponent
	print "ZC(error)..."
	n=int(ma.log(N,2))
	Z=pl.ZBSC(p)	
	ZN=Zconstruct(pl.ZBSC(p),n)
	aZN=np.array(ZN)
	sZN=np.sort(aZN)
	exp_error=np.log10(sZN).tolist()
	#print exp_error
	K=0
	for i in exp_error:
		if i<=L:
			K+=1
	
	good_channels=aZN.argsort().tolist()[:K]
	rgood_channels=ec.bitreverseorder(good_channels,n)
	
	
	f2=open("./simresults/GCZL_"+str(N)+"_"+str(p).replace(".","p")+"_"+str(L)+".txt",'w')
	json.dump(rgood_channels,f2)
	
	return (rgood_channels,exp_error[:K])


#---------------------------------Monte Carlo

def getGChMCK(p,N,K,runsim):
	n=int(ma.log(N,2))
	err=np.zeros(N)
	print "MC(K)..."+str(runsim)
	for i in range(runsim):
		UN=np.random.randint(2,size=N)
		UN_decoded=ec.polarSCdecode(pl.BSCN(p,ec.polarencode(UN,len(UN))),len(UN),p)
		err=err+np.logical_xor(UN,UN_decoded)
	
	aZN=err/runsim
	sZN=np.sort(aZN)
	good_channels=aZN.argsort().tolist()[:K]
	exp_error=np.log10(sZN).tolist()
	
	
	
	f2=open("./simresults/GCMK_"+str(N)+"_"+str(p).replace(".","p")+"_"+str(K)+".txt",'w')
	json.dump(good_channels,f2)
	
	return (good_channels,exp_error[:K],exp_error)
	
def getGChMCL(p,N,L,runsim):
	n=int(ma.log(N,2))
	err=np.zeros(N)
	print "MC(error)..."+str(runsim)
	for i in range(runsim):
		UN=np.random.randint(2,size=N)
		UN_decoded=ec.polarSCdecode(pl.BSCN(p,ec.polarencode(UN,len(UN))),len(UN),p)
		err=err+np.logical_xor(UN,UN_decoded)
	
	aZN=err/runsim
	sZN=np.sort(aZN)
	exp_error=np.log10(sZN).tolist()
	#print exp_error
	K=0
	for i in exp_error:
		if i<=L:
			K+=1
	
	good_channels=aZN.argsort().tolist()[:K]
	
	
	f2=open("./simresults/GCML_"+str(N)+"_"+str(p).replace(".","p")+"_"+str(L)+".txt",'w')
	json.dump(good_channels,f2)
	
	
	#print exp_error
	return (good_channels,exp_error[:K],exp_error)
#----------------------------------------------------------load sim results
def getGCHsim(tsim,N,p,param): # tsim = ML / MK/ ZL/ ZK
		
		filename="./simresults/GC"+str(tsim)+"_"+str(N)+"_"+str(p).replace(".","p")+"_"+str(param)+".txt"
		f1=open(filename,'r')
		return json.load(f1)
		

	
#=================================================================simulation	
"""
#reliability ordering
N=128
plist=[0.01,0.1,0.2,0.3]
print "N="+str(N)+"\n"

for p in plist:
	print "p="+str(p)+"\n"
	print getGChZCK(p,N,N)
"""

print getGChZCL(0.1,32,-2)


"""	
#------------Number of good channels = capacity
Nlist=[128,256,1024]
plist=[0.05,0.1,0.2]
K=5
tolerable_error= -5
runsim=(10**(-tolerable_error))*2

for N in Nlist:
	for p in plist:
	
		
		

		#runsim for K
		#runsim=1000

		#-----------------------
		stamp=datetime.now().strftime("%d-%y-%m_%H-%M-%S")
		f1=open("./simresults/polarconstruct"+stamp+".txt",'w')



		print "MONTE _CARLO CHANNEL REPORT"
		print "---------------------------"

		print "N="+str(N)
		print "p="+str(p)
		PotGCh=int(ma.floor(pl.CapacityBSC(N,p)))
		print "Capacity for "+str(N)+"channels:"+str(PotGCh)



		print "No of good channels needed :"+str(K)+"(valid if used)"
		print "tolerable error exponent:"+str(tolerable_error)
		#-----------------------------------------ZC
		(I,E)=getGChZCL(p,N,tolerable_error)
		#(I,E)=getGChZCK(p,N,K)
		print "Good Channels:"
		print I
		print "Corresponding Error Exponents:"
		print E
		print "Number of good channels:"
		print len(I)
		R=float(len(I))/N
		print "R="+str(R)
		print "Frozen channels:"
		B=list(set(range(N))-set(I))
		print len(B)

##########################################file
		json.dump( "MONTE _CARLO CHANNEL REPORT",f1) ;f1.write("\n")
		json.dump( "---------------------------",f1) ;f1.write("\n")
		json.dump( "N="+str(N),f1) ;f1.write("\n")
		json.dump( "p="+str(p),f1) ;f1.write("\n")
		json.dump( "Capacity for "+str(N)+"channels:"+str(PotGCh),f1) ;f1.write("\n")
		json.dump( "No of good channels needed :"+str(K)+"(valid if used)",f1) ;f1.write("\n")
		json.dump( "tolerable error exponent:"+str(tolerable_error),f1) ;f1.write("\n")
#-----------------------------------------ZC
		json.dump("Z Construct--------------------------------------------------------",f1);f1.write("\n")
		json.dump( "Good Channels:",f1) ;f1.write("\n")
		json.dump( I,f1) ;f1.write("\n")
		json.dump( "Corresponding Error Exponents:",f1) ;f1.write("\n")
		json.dump( E,f1) ;f1.write("\n")
		json.dump( "Number of good channels:",f1) ;f1.write("\n")
		json.dump( len(I),f1) ;f1.write("\n")
		json.dump( "R="+str(R),f1) ;f1.write("\n")
		json.dump( "Frozen channels:",f1) ;f1.write("\n")
		json.dump( len(B),f1) ;f1.write("\n")
		
	
		#-------------------------------------MC

		(I,E,FE)=getGChMCL(p,N,tolerable_error,runsim)
		#(I,E,FE)=getGChMCK(p,N,K,runsim)
		print "Good Channels:"
		print I
		print "Corresponding Error Exponents:"
		print E
		print "Number of good channels:"
		print len(I)
		R=float(len(I))/N
		print "R="+str(R)
		print "Frozen channels:"
		B=list(set(range(N))-set(I))
		print len(B)
		###################################file
		json.dump("Monte Carlo--------------------------------------------------------",f1);f1.write("\n")
		json.dump("sim ran :"+str(runsim),f1) ;f1.write("\n")
		json.dump( "Good Channels:",f1) ;f1.write("\n")
		json.dump( I,f1) ;f1.write("\n")
		json.dump( "Corresponding Error Exponents:",f1) ;f1.write("\n")
		json.dump( E,f1) ;f1.write("\n")
		json.dump( FE,f1);f1.write("\n")
		json.dump( "Number of good channels:",f1) ;f1.write("\n")
		json.dump( len(I),f1) ;f1.write("\n")
		json.dump( "R="+str(R),f1) ;f1.write("\n")
		json.dump( "Frozen channels:",f1) ;f1.write("\n")
		json.dump( len(B),f1) ;f1.write("\n")
		

"""
