#-------------------------------------------------------------------------------
# Name:       monte-carlo for charaterising channel
# Purpose:    related to prob and channel
#
# Author:      soumya
#
# Created:     04/08/2017
#----------------------------------------
import numpy as np
import math as ma

#simulation params
runsim=100

#BSC param
p=0.2
N=8
n=int(ma.log(N,2))

UN=np.array([0,0,0,0,0,0,0,0]) #all zero sequence
#n=int(ma.log(np.size(Un),2))


for i in range(runsim):
	YN=BSCN(p,polarencode(UN,N))
