#-------------------------------------------------------------------------------
# Name:      probability-library
# Purpose:    related to prob and channel
#
# Author:      soumya
#
# Created:     04/08/2017
#----------------------------------------
import numpy as np
import math as ma

#===============================================================ber rv
def ber(p):
	#can be done using a set of uniform draws mapped to 1 , say 2/10
	# and the other set mapped to 0
	
	return np.random.binomial(1,p) # ber is bin with n=1

#Note : bit is integer, inbitarray is integer array
#-------------------------------------------------------------------
def condp(p,y,x):
	if y==x:
		return 1-p
	else:
		return p

#------------------------------------------------------------------
def LLR(p,y):
    return ma.log(condp(p,y,1)/condp(p,y,0))

#===========================================================BSC channel

#---------------------------------------------------------1 BSC channel
def BSC1(p,bit): #p is flip over 
	return ber(p)^bit

#---------------------------------------------------------n BSC channel
def BSCN(p,inbitarray):
	N=np.size(inbitarray)
	flip=np.random.binomial(1,p,N) #generates N ber(p) instances
	outbitarray=np.logical_xor(inbitarray,flip)
	return outbitarray

#old	
def BSCN_1(p,inbitarray):
	N=np.size(inbitarray)
	#print n
	outbitarray=np.array([])
	
	for i in range(n):
		outbitarray=np.append(outbitarray,BSC1(p,inbitarray[i]))

	return outbitarray #outbitarray is float


#returns error vector    
def BSCNe(p,inbitarray):
	return np.logical_xor(BSCN(p,inbitarray),inbitarray)

#----------------------------------------------------------------------
#s=0	
#for i in range(100):
#    s=s+ber(0.5)
#print s	

#s=0	
#for i in range(100):
#    s=s+BSC1(0.1,1)
#print s		

#print float(sum(BSCN(0.4,np.zeros((1000,), dtype=np.int))))/1000

#print sum(BSCN_1(0.2,np.zeros((1000,), dtype=np.int)))/1000
