#-------------------------------------------------------------------------------
# Name:       polar library
# Purpose:    polar coding and decoding
#
# Author:      soumya
#
# Created:     04/08/2017
# Encoding: following arikan lectures
# Decoding : following Harish Vangala
#
#----------------------------------------

import numpy as np
import matlib as ml
import math as ma
import problib as pl

#======================================================support functions
def getF(n):
	F=np.array([[1,0],[1,1]])
	return ml.kronpow(F,n) 

#---------------------------------------------------decoding likelihood
#l1=llr1, l2=llr2
#f=ma.log((1+ma.exp(l1+l2))/(exp(l1)+exp(l2)))
#NOTE:
#in UN_decoded root of computation tree is flevel 0 there are n levels(n+1 th level is Yn and not considered)
#in LL leaf is level 0 and there are n+1 levels
#flevel = n - level

def f(l1,l2):
	if l1==-999 or l2==-999:
		return -999
	fval=np.sign(l1)*np.sign(l2)*min(abs(l1),abs(l2))
	return fval

def g(l1,l2,fbit):
	if fbit==-1 or l1==-999 or l2==-999:
		return -999
	else:	
		gval=l2+((-1)**fbit)*l1
		return gval
    
def active_levels(i,n):
	i_bin="{0:0{width}b}".format(i,width=n)
	i_bin.zfill(n)
	acl=0
	for j in i_bin:
		if j=='0':
			acl+=1
		else:
			break;
	return min(acl+1,n+1)
	
def ML(llr):
	if llr==-999:
		return -1
	if llr>0:
		return 1
	else:
		return 0
		
def bitreverseorder(J,n):
	#J is list of indices
	RJ=[]
	for i in J:
	 RJ.append(int('{:0{width}b}'.format(i,width=n)[::-1], 2))		
	return RJ

def isupperrow(requested_row,level):
	setindex=int(requested_row/(2**level))
	if setindex%2==0:
		return True
	else:
		return False
	 
	
#print isupperrow(3,0)	
#print isupperrow(3,1)	
#print isupperrow(3,2)	
#print isupperrow(3,3)	

#this function does not return anything, populates UN[requested_row][level]	
def bitrequest(UN_decoded,requested_row,level,n):
	flevel=n-level
	print level,flevel
	print "IN bit req"
	
	
	if UN_decoded[requested_row][flevel]!= -1 or flevel==0:#UN_decoded vector
		return
	else:
		if isupperrow(requested_row,level):
			print "upper row"
			print requested_row,flevel-1
			print requested_row+(2**(level)),flevel-1
			
			
			if UN_decoded[requested_row][flevel-1]== -1:
				
				
				bitrequest(UN_decoded,requested_row,n-(flevel-1),n)	
				
					
			if UN_decoded[requested_row+(2**(level))][flevel-1] == -1:
				
				
				bitrequest(UN_decoded,requested_row+(2**(level)),n-(flevel-1),n)
						
				
			print UN_decoded[requested_row][flevel-1],UN_decoded[requested_row+(2**(level))][flevel-1]
			UN_decoded[requested_row][flevel]=int(UN_decoded[requested_row][flevel-1]) ^ int(UN_decoded[requested_row+(2**(level))][flevel-1])
			
				
				
		else:	
			print "lower row"		
			print requested_row,flevel-1
			if UN_decoded[requested_row][flevel-1]== -1:
				bitrequest(UN_decoded,requested_row,n-(flevel-1),n)
			
				
			
			UN_decoded[requested_row][flevel]=UN_decoded[requested_row][flevel-1]
			
			
		print "updated UN "+str(requested_row)+" "+str(flevel)
		print UN_decoded[requested_row][flevel]
		print UN_decoded
				
				
			    
			    
			    
def getLLR(p,n,decodebit,requested_row,g_level,level,LL,UN_decoded,YN):
	#g_level is last active level 
	#print "start"
	if level<g_level:
		return
	print "request"	
	print requested_row,level
	#print decodebit,requested_row,level
	ffl=0
	gfl=0
	if LL[requested_row][level] == -999:
		if level==g_level:
		
			if decodebit==0:
				
				LL[requested_row][level]=pl.LLR(p,YN[requested_row])
				#print requested_row,level
				
			
			else:
				gfl=1
				print "calling for g " + str(requested_row-2**(level - 1))+","+str(requested_row)
				
				getLLR(p,n,decodebit,requested_row-(2**(level - 1)),g_level,level-1,LL,UN_decoded,YN)
				getLLR(p,n,decodebit,requested_row,g_level,level-1,LL,UN_decoded,YN)
				bitrequest(UN_decoded,requested_row-(2**(level - 1)),level,n)
				
				
				LL[requested_row][level] = g(LL[requested_row-(2**(level - 1))][level-1],LL[requested_row][level-1],UN_decoded[requested_row-(2**(level - 1))][n-level])
				
		else:
		   	print "calling for f " + str(requested_row)+","+str(requested_row+(2**(level - 1)))		    
			getLLR(p,n,decodebit,requested_row,g_level,level-1,LL,UN_decoded,YN)
			getLLR(p,n,decodebit,requested_row+(2**(level - 1)),g_level,level-1,LL,UN_decoded,YN)
		
			LL[requested_row][level]=f(LL[requested_row][level-1],LL[requested_row+(2**(level - 1))][level-1])
			ffl=1
			
	print "back",requested_row,level
	if ffl==1:
		try:
			print LL[requested_row][level-1],LL[requested_row+(2**(level - 1))][level-1]
			print f(LL[requested_row][level-1],LL[requested_row+(2**(level - 1))][level-1])
		except:
			pass
	if gfl==1:
		try:
		
			print LL[requested_row-(2**(level - 1))][level-1],LL[requested_row][level-1],UN_decoded[requested_row-(2**(level - 1))][n-level]
			print g(LL[requested_row-(2**(level - 1))][level-1],LL[requested_row][level-1],UN_decoded[requested_row-(2**(level - 1))][n-level])
			print UN_decoded
		except:
			pass
		
	print LL
	
	
	
		
#======================================================encode - decode


#----Use recursion

def polarencode(UN,N): #Un is original bit array
	n=int(ma.log(N,2))
	Fn=getF(n)
	XNd=np.dot(UN,Fn)
	XN=np.mod(XNd,2)
	return XN        #XN enters channel


def polarSCdecode(YN,N,p): #YN is OP of channel
	n=int(ma.log(N,2))
	UN_decoded=np.zeros((N,n))-1
	LL=np.zeros((N,n+1))-999 #likelihoods will rarely be equal to -999
	
	dec_order=bitreverseorder(range(N),n)
    
   
	for i in dec_order:
		
		print "decoding "+ str(i)
		print "--------------------"
		#LLR flow
		No_act_levels=active_levels(i,n)
		act_levels=n-np.array(range(No_act_levels),dtype=int)
		print act_levels

		getLLR(p,n,i,i,min(act_levels),max(act_levels),LL,UN_decoded,YN)
		UN_decoded[i][0]=int(ML(LL[i][3]))
	
		
		print "final"	
		print 	LL
		print UN_decoded
		
		
	    #bit flow
	    
#----------------------------------------coding decoding sim
n=13
p=0.3
UN=np.random.randint(2,size=2**n)		
polarSCdecode(pl.BSCN(p,polarencode(UN,len(UN))),len(UN),p)
print UN
print polarencode(UN,len(UN))
print pl.BSCN(p,polarencode(UN,len(UN)))	
#---------------------------------------------------------------------
#print getF(3)
#print 	bitreverseorder(range(8),3)
#print active_levels(0,3)
#print active_levels(4,3)
#print polarencode([1,0,0,0,1,1,1,1],8)	

